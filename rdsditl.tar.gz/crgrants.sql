set head off
set pages 0
set long 9999999

REM
REM RUN THIS SCRIPT ON THE SOURCE DATABASE USING THE SYS OR SYSTEM USER.
REM THE OUTPUT OF THIS FILE SHOULD BE EXECUTED ON THE RDS DATABASE
REM USING THE RDS ADMIN USER.
REM

REM
REM REVIEW THE OUTPUT FILE THOROUGHLY PRIOR TO EXECUTING IN RDS ORACLE
REM

select dbms_metadata.get_granted_ddl('TABLESPACE_QUOTA', tq.username)|| ';' AS ddl
from   dba_ts_quotas tq
where  tq.username not in ('SYSTEM', 'SYS', 'SYSAUX', 'DBSNMP', 'OUTLN')
union all
select dbms_metadata.get_granted_ddl('ROLE_GRANT', rp.grantee)|| ';' AS ddl
from   dba_role_privs rp
where  rp.grantee not in ('SYSTEM', 'SYS', 'SYSAUX', 'DBSNMP', 'OUTLN')
union all
select dbms_metadata.get_granted_ddl('SYSTEM_GRANT', sp.grantee)|| ';' AS ddl
from   dba_sys_privs sp
where  sp.grantee not in ('SYSTEM', 'SYS', 'SYSAUX', 'DBSNMP', 'OUTLN')
union all
select dbms_metadata.get_granted_ddl('OBJECT_GRANT', tp.grantee)|| ';' AS ddl
from   dba_tab_privs tp
where  tp.grantee not in ('SYSTEM', 'SYS', 'SYSAUX', 'DBSNMP', 'OUTLN')
union all
select dbms_metadata.get_granted_ddl('DEFAULT_ROLE', rp.grantee)|| ';' AS ddl
from   dba_role_privs rp
where  rp.grantee not in ('SYSTEM', 'SYS', 'SYSAUX', 'DBSNMP', 'OUTLN')
and    rp.default_role = 'YES'
union all
select dbms_metadata.get_ddl('PROFILE', u.profile)|| ';' AS ddl
from   dba_users u
where  u.username not in ('SYSTEM', 'SYS', 'SYSAUX', 'DBSNMP', 'OUTLN')
and    u.profile <> 'DEFAULT';

