SET VERIFY OFF
SET FEEDBACK OFF
SET SERVEROUTPUT ON SIZE 30000
 
DECLARE
  ind NUMBER;              -- Loop index
  h1 NUMBER;               -- Data Pump job handle
  percent_done NUMBER;     -- Percentage of job complete
  job_state VARCHAR2(30);  -- To keep track of job state
  le ku$_LogEntry;         -- For WIP and error messages
  js ku$_JobStatus;        -- The job status from get_status
  jd ku$_JobDesc;          -- The job description from get_status
  sts ku$_Status;          -- The status object returned by get_status

BEGIN

--
-- Execute using the RDS Admin user
--

--
-- This script uses the Data Pump API
--

--
-- Create a (user-named) Data Pump job to do an import
--

  DBMS_OUTPUT.PUT_LINE('Opening file handler');

  h1 := DBMS_DATAPUMP.OPEN(operation => 'IMPORT',
                           job_mode =>'SCHEMA',
                           job_name => NULL);

--
-- Specify the single dump file for the job (using the handle just returned)
-- and directory object, which must already be defined and accessible
-- to the user running this procedure. This is the dump file created by
-- the export operation in the first example.
--

-- 
-- If multiple files are required, please use the wildcard expression of '%U'.
-- For example, 'export_data%U', will capture export_data.dmp, export_data01.dmp, 
--               export_data02.dmp, export_data03.dmp, etc.
--

--
-- Another example is below:
-- dbms_datapump.add_file(handle => h1, filename => 'EXPDAT%U' || 
--    to_char(sysdate, 'dd-mm-yyyyhh24miss') || '.DMP', directory => 'DATA_PUMP_DIR', 
--    filetype => 1);
-- 

  DBMS_OUTPUT.PUT_LINE('Adding files to handler');

  DBMS_DATAPUMP.ADD_FILE(handle => h1,
                         filename => 'export_data.dmp',
                         directory => 'DATA_PUMP_DIR',
                         filetype => dbms_datapump.ku$_file_type_dump_file);

  DBMS_DATAPUMP.ADD_FILE(handle => h1,
                         filename => 'export_data.log',
                         directory => 'DATA_PUMP_DIR',
                         filetype => dbms_datapump.ku$_file_type_log_file);

--
-- A metadata remap will map all schema objects from SOURCESCHEMA to TARGETSCHEMA.
-- CHANGE THIS TO YOUR SOURCE AND TARGET SCHEMAS
--

  DBMS_OUTPUT.PUT_LINE('Remapping Schema');

  DBMS_DATAPUMP.METADATA_REMAP(h1,'REMAP_SCHEMA','HR','DEMO');

--
-- A metadata filter is used to specify the schema that will be exported.
-- DBMS_DATAPUMP.METADATA_FILTER(h1,'SCHEMA_EXPR','IN (''HR'')');
--

--
-- If a table already exists in the destination schema, skip it (leave
-- the preexisting table alone). This is the default, but it does not hurt
-- to specify it explicitly.
--

-- DBMS_DATAPUMP.SET_PARAMETER(h1,'TABLE_EXISTS_ACTION','SKIP');

--
-- Start the job. An exception is returned if something is not set up properly.
--

  DBMS_OUTPUT.PUT_LINE('Starting Data Pump Job');

  DBMS_DATAPUMP.START_JOB(h1);

  dbms_output.put_line('Job has completed');

  dbms_datapump.detach(h1);

END;
/
