exec rdsadmin.rdsadmin_util.alter_default_tablespace(tablespace_name => 'USERS');
