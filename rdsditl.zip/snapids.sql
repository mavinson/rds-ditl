set heading off
set pages 999
set lines 132
column FILENAME format a60
select snap_id from dba_hist_snapshot order by snap_id asc;
