SELECT rdsadmin.rdsadmin_s3_tasks.upload_to_s3(p_bucket_name => 'mv-rds-exports', p_prefix =>'awr', p_s3_prefix =>'', p_directory_name => 'DATA_PUMP_DIR') AS TASK_ID FROM DUAL;
