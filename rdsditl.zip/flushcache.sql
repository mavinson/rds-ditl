exec rdsadmin.rdsadmin_util.flush_buffer_cache;
