select * from v$log;
exec rdsadmin.rdsadmin_util.add_logfile(p_size => '128M');
select * from v$log;
