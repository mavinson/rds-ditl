exec rdsadmin.rdsadmin_util.set_configuration( name => 'archivelog retention hours', value => '48');
