set sqlformat ansiconsole
set time on
