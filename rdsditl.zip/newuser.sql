create user mavinson identified by mavinson default tablespace users;
grant connect, resource, dba to mavinson;
