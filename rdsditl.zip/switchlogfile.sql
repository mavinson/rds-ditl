exec rdsadmin.rdsadmin_util.switch_logfile;
