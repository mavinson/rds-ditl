begin
    rdsadmin.rdsadmin_util.kill(
        sid    => 1904, 
        serial => 60255);
end;
/
