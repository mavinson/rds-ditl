-- exec rdsadmin.rdsadmin_util.create_directory(p_directory_name => 'BACKUP'); 

-- exec rdsadmin.rdsadmin_util.set_configuration( name  => 'archivelog retention hours', value => '48');

SELECT * FROM table(rdsadmin.rds_file_util.listdir('BACKUP')) order by mtime;

exec rdsadmin.rdsadmin_rman_util.backup_database_full ( p_owner => 'SYS', p_directory_name => 'BACKUP', p_include_archive_logs => TRUE, p_parallel => 4, p_section_size_mb => 100, p_rman_to_dbms_output => FALSE ); 

SELECT * FROM table(rdsadmin.rds_file_util.listdir('BACKUP')) order by mtime;

SELECT rdsadmin.rdsadmin_s3_tasks.upload_to_s3(p_bucket_name => 'mv-rds-exports', p_prefix =>'', p_s3_prefix =>'', p_directory_name => 'BACKUP') AS TASK_ID FROM DUAL;

-- select text FROM table(rdsadmin.rds_file_util.read_text_file('BDUMP','dbtask-NNNNNNNNNNNNN-NNNN.log'));

