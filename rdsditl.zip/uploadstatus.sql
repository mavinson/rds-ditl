select text FROM table(rdsadmin.rds_file_util.read_text_file('BDUMP','dbtask-1657227585895-1912.log'));
