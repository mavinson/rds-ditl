select num, name, value from v$parameter where lower(name) like '%&&init_in_lowercase%';
