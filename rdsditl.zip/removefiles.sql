begin
    for i in (select filename from 
    table(RDSADMIN.RDS_FILE_UTIL.LISTDIR('BACKUP')) where type='file')
    loop
    UTL_FILE.FREMOVE ('BACKUP', i.filename);
    end loop;
end;
/

