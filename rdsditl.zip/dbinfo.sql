select dbid, name, db_unique_name, controlfile_type from v$database;
